/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.dataflow.analysis;

import pascal.taie.analysis.dataflow.fact.SetFact;
import pascal.taie.analysis.graph.cfg.CFG;
import pascal.taie.config.AnalysisConfig;
import pascal.taie.ir.exp.LValue;
import pascal.taie.ir.exp.RValue;
import pascal.taie.ir.exp.Var;
import pascal.taie.ir.stmt.Stmt;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of classic live variable analysis.
 */
public class LiveVariableAnalysis extends
        AbstractDataflowAnalysis<Stmt, SetFact<Var>> {

    public static final String ID = "livevar";

    public LiveVariableAnalysis(AnalysisConfig config) {
        super(config);
    }

    @Override
    public boolean isForward() {
        return false;
    }

    @Override
    public SetFact<Var> newBoundaryFact(CFG<Stmt> cfg) {
        // TODO - finish me
        // IN[exit] = emptySet()
        return new SetFact<>();
        //return null;
    }

    @Override
    public SetFact<Var> newInitialFact() {
        // TODO - finish me
        //IN[B] = emptySet()
        return new SetFact<>();
    }

    @Override
    public void meetInto(SetFact<Var> fact, SetFact<Var> target) {
        // TODO - finish me
        //public boolean union(SetFact<E> other) {
        //        return set.addAll(other.set);
        //    }
        target.union(fact);
    }

    @Override
    public boolean transferNode(Stmt stmt, SetFact<Var> in, SetFact<Var> out) {
        // TODO - finish me
        //IN[B] = union(use_B, OUT[B]-def_B)
        //Optional<LValue> getDef()
        //List<RValue> getUses()
        SetFact<Var> in_copy = in.copy();
        SetFact<Var> out_copy = out.copy();
        List<RValue> use_B = stmt.getUses();
        Optional<LValue> def_B = stmt.getDef();
        //OUT[B]-def_B
        if(def_B.isPresent())
        {
            if (def_B.get() instanceof Var) {
                out_copy.remove((Var) def_B.get());
            }
        }
        //public boolean union(SetFact<E> other) {
        //        return set.addAll(other.set);
        //    }
        //union(use_B, OUT[B]-def_B)
        for (RValue rValue : use_B) {
            if (rValue instanceof Var) {
                out_copy.add((Var) rValue);
            }
        }
        in.union(out_copy);
        return !in.equals(in_copy);
    }
}
